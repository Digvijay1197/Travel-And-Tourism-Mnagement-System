package com.app.entities;

public enum IdProof {
	AADHAR_CARD, DRIVING_LICENSE, PAN_CARD
}
