package com.app.entities;

public enum TransportationMode {
	BUS, TRAIN, FLIGHT
}
