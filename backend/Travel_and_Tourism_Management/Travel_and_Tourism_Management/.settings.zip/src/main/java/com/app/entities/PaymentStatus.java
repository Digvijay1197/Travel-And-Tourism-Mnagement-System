package com.app.entities;

public enum PaymentStatus {
	PAYMENT_SUCCESSFUL, PAYMENT_FAILED, PAYMENT_NOT_DONE, PAYMENT_IN_PROGRESS;
}
