package com.app.entities;

public enum TourTypeEnum {
HOLIDAY,INTERNATIONAL,DOMESTIC,ACTIVITIES;
}
