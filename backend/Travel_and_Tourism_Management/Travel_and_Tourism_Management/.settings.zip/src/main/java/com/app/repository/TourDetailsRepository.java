package com.app.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.entities.TourDetails;
import com.app.entities.TourTypeEnum;

public interface TourDetailsRepository extends JpaRepository<TourDetails, Long> {

	Optional<List<TourDetails>> findByDestination(String destination);
	
	Optional<List<TourDetails>> findByTourType(TourTypeEnum tourType);
}
